# README #

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###

*this is a compulsory assigment for school

### Who do I talk to? ###

* poul@rgb-web.dk